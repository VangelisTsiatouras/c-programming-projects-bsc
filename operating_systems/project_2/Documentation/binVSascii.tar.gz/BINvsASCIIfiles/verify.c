// Author: A. Delis ad@di.uoa.gr
#include <stdio.h>
#include <unistd.h>

#include "myRecordDef.h"


int main (int argc, char** argv) {
   FILE *filepointer;
   MyRecord rec;
   long lSize;
   int numOfrecords, i;
   
   if (argc!=2) {
      	printf("Correct syntax is: %s BinaryFile\n", argv[0]);
      	return(1);
   	}

   filepointer = fopen (argv[1],"rb");
   if (filepointer==NULL) {
      	printf("Cannot open binary file\n");
      	return 1;
   	}

   /* check number of records */
   fseek (filepointer, 0 , SEEK_END);
   lSize = ftell (filepointer);
   rewind (filepointer);
   numOfrecords = (int) lSize/sizeof(rec);

   /* un-comment this to see how "rewind"-ing works
   printf("Records found in file %d \n", numOfrecords);
   sleep(5);
   */
   
   for (i=0; i<numOfrecords ; i++) {
      	fread(&rec, sizeof(rec), 1, filepointer);
      	printf("%f %f %f\n", rec.x, rec.y, rec.z);
   	}

   fclose (filepointer);
}
