#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "myRecordDef.h"

FILE 	*filepointer;

double  GetRandomInRange(int range){
double  k=0;

	k=(random() % range);
        return((double)k);
}


/**** 	Main 	***/
void	main(int argc, char *argv[]){
int	i=0, myseed, numOfRecs2Produce=0;
int 	xrange=0, yrange=0, zrange=0;
double	tempx=0.00, tempy=0.00, tempz=0.00;

if (argc!=7) {
	printf("executable seed numeOfRecs x-range y-range z-range binfile-name\n");
	exit(1);
	}

myseed=atoi(argv[1]);
numOfRecs2Produce=atoi(argv[2]);
srandom(myseed);

xrange=atoi(argv[3]);
yrange=atoi(argv[4]);
zrange=atoi(argv[5]);

MyRecord	RecordHolder;

filepointer = fopen (argv[6],"wb"); /* open the argv[6] file for writing in binary! */
if (filepointer==NULL) {
        printf("Cannot open file \n");
        exit(1);
        }

for(i=0;i<numOfRecs2Produce;i++){
        tempx = GetRandomInRange(xrange);
	tempy = GetRandomInRange(yrange);
	tempz = GetRandomInRange(zrange);

	// printf("%8.2f %8.2f\n",tempx,tempy);

        RecordHolder.x = tempx;
        RecordHolder.y = tempy;
        RecordHolder.z = tempz;

        fwrite(&RecordHolder, sizeof(RecordHolder), 1, filepointer);
	tempx=0.00;
	tempy=0.00;
	tempz=0.00;
	}

fclose(filepointer);
}
