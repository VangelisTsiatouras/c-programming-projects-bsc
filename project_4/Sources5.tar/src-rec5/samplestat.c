#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/stat.h>

/* D. Savvas */

int main ( int argc , char * argv []) {
  struct stat statbuf ;
  struct tm lt;
  if ( stat ( argv [1] , &statbuf ) == -1) {
    perror ( " Failed to get file status " );
    exit (2) ;
  }
  else{
    char str_access[100];
    char str_modify[100];
    /* convert time_t to struct tm (access time)*/
    localtime_r(&statbuf.st_atime,&lt); 
    /* use localtime_r instead of localtime*/
    /* create the string representation of lt */
    strftime(str_access, sizeof(str_access), "%c", &lt);

    /* do the same for modify time */
    localtime_r(&statbuf.st_mtime,&lt);
    strftime(str_modify, sizeof(str_modify), "%c", &lt);

    printf("\n>> Correct Execution \n File: %s \n accessed : %s \n modified : %s " , argv [1], str_access, str_modify);

    /* This code won't work, because ctime uses a static variable 
	where it stores the result */
    printf("\n\n>> Wrong Execution \n File: %s \n accessed : %s modified : %s" , argv [1] , ctime(&statbuf.st_atime) , ctime(&statbuf.st_mtime)) ;
    /* It will compute the results of ctime(s) calls. and use the pointers to print */
    printf("\n-->> Pointer 1: %p, Pointer 2: %p\n",ctime(&statbuf.st_atime) , ctime(&statbuf.st_mtime));
    /* However, these two pointers are the same */

    /* This code works well, because we use two printf calls */
    printf("\n>> Correct Exeution but to be Avoided: \n");
    printf(" File: %s \n",argv[1]);
    printf(" accessed : %s",ctime(&statbuf.st_atime));
    printf(" modified : %s \n",ctime(&statbuf.st_mtime));
    /* However, POSIX.1-2008 marks asctime(),
		   asctime_r(), ctime(), and ctime_r() as obsolete,
		   recommending the use
		   of strftime(3) instead.*/
  }
  return (1) ;
}

